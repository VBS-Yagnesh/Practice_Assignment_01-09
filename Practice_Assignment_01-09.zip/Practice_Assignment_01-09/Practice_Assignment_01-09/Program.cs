﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Practice_Assignment_01_09
{
    class Program
    {
        static void Main(string[] args)
        {

            // 1) Display the name of the Week On the basis of No Entered by the user using Switch Statement  
            //     Monday = 2 and Sunday = 1 etc

            // -------------ANSWER--------------------------------

            //Console.WriteLine("Enter day num: ");
            //int aday = Convert.ToInt32(Console.ReadLine());
            //switch (aday)
            //{
            //    case 1:
            //        Console.WriteLine("Monday");
            //        break;
            //    case 2:
            //        Console.WriteLine("Tuesday");
            //        break;
            //    case 3:
            //        Console.WriteLine("Wednesday");
            //        break;
            //    case 4:
            //        Console.WriteLine("Thursday");
            //        break;
            //    case 5:
            //        Console.WriteLine("Friday");
            //        break;
            //    case 6:
            //        Console.WriteLine("Satday");
            //        break;
            //    case 7:
            //        Console.WriteLine("Sunday");
            //        break;
            //    default:
            //        Console.WriteLine("Error");
            //        break;
            //}

            //***********************************************


            //2) WAP to Implement Array of Integer with following functionality

            //Inserting 5 Elements

            //Displaying using For loop

            //Deleting 2 Elements

            //Displaying using Foreach loop

            //Sorting Elements

            //Displaying using Foreach loop

            //Displaying MAX, MIN, SUM of an Array

            //---------------------ANSWER--------------------------

            //int[] numb = { 20, 32, 44, 12, 7 };
            //for (int i = 0; i < numb.Length; i++)
            //{
            //    Console.WriteLine(numb[i]);
            //}
            //Console.WriteLine("Max: " + numb.Max());
            //Console.WriteLine("Min: " + numb.Min());
            //Console.WriteLine("Sum: " + numb.Sum());
            //Array.Sort(numb);
            //Console.WriteLine("Sorted Array: ");
            //foreach (var item in numb)
            //{
            //    Console.WriteLine(item);
            //}

            // *****************************************************

            // 3) i)-----------------Generic Stack------------------------

            //Stack<string> cities = new Stack<string>();
            //cities.Push("Chicago");
            //cities.Push("Melbourne");
            //cities.Push("London");
            //cities.Push("Mumbai");
            //cities.Push("Tokyo");
            //cities.Push("Munich");
            //cities.Push("New York");

            //foreach (var items in cities)
            //{
            //    Console.WriteLine(items);
            //}
            //Console.WriteLine("------");
            //Console.WriteLine("Cities.POP: " + cities.Pop());
            //Console.WriteLine("------");
            //Console.WriteLine("Cities.PEEK: " + cities.Peek());


            // 3) ii)----------Non Generic Stack--------------------------

            //Stack Mystack = new Stack();
            //Mystack.Push(3);
            //Mystack.Push("to the");
            //Mystack.Push(2);
            //Mystack.Push("to the");
            //Mystack.Push(1);
            //Mystack.Push(0.012);
            //Mystack.Push("Hey !");
            //foreach(var item in Mystack)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine("------");
            //Console.WriteLine("Mystack.POP: " + Mystack.Pop());
            //Console.WriteLine("------");
            //Console.WriteLine("Mystack.Peek: " + Mystack.Peek());


            // 3) iii)---------Generic Queue----------------------

            //Queue<string> cities = new Queue<string>();
            //cities.Enqueue("Chicago");
            //cities.Enqueue("Melbourne");
            //cities.Enqueue("London");
            //cities.Enqueue("Mumbai");
            //cities.Enqueue("Tokyo");
            //cities.Enqueue("Munich");
            //foreach(var item in cities)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine("------");
            //Console.WriteLine("Citites.Dequeue: " + cities.Dequeue());
            //Console.WriteLine("------");
            //Console.WriteLine("Citites.Peek: " + cities.Peek());
            //Console.WriteLine("------");
            //Console.WriteLine("Count: " + cities.Count);

            // 3) iV)------------Non Generic Queue----------------

            //Queue Myqu = new Queue();
            //Myqu.Enqueue("Hey !");
            //Myqu.Enqueue(0.0123);
            //Myqu.Enqueue(1);
            //Myqu.Enqueue("to the");
            //Myqu.Enqueue(2);
            //Myqu.Enqueue("to the");
            //Myqu.Enqueue(3);
            //foreach (var item in Myqu)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine("------");
            //Console.WriteLine("Count: " + Myqu.Count);
            //Console.WriteLine("------");
            //Console.WriteLine("Dequeue: " + Myqu.Dequeue());
            //Console.WriteLine("------");
            //Console.WriteLine("Peek: " + Myqu.Peek());
            //Console.WriteLine("------");
            //Console.WriteLine("Count: " + Myqu.Count);

            // 3) V)----------------Hastable-Non Generic------------------------

            //Hashtable myht = new Hashtable();
            //myht.Add(1, "abc");
            //myht.Add(2, "jyc");
            //myht.Add(3, "jofg");
            //myht.Add(4, "okwed");
            //foreach(DictionaryEntry item in myht)
            //{
            //    Console.WriteLine($"key: {item.Key}, value: {item.Value}");

            //}
            //Console.WriteLine(myht.Contains(4));
            //Console.WriteLine(myht.ContainsValue("abc"));

            //*************************************************

            //4) WAP to implement Dictionary for following types: 
            //AuthorList<string, Int16>
            //Along with implementation of : 
            //Adding 3 elements
            //Removing an element
            //Finding a Key / Value
            //Clearing collection
            //Displaying the count

            //--------------ANSWER---------------------

            //Dictionary<string, Int16> Authors = new Dictionary<string, Int16>();
            //Authors.Add("Cannon Aurthor Doyle", 20);
            //Authors.Add("Charles Dickens", 18);
            //Authors.Add("Premchand", 80);
            //Authors.Add("JK Rowling", 16);
            //foreach(KeyValuePair<string, Int16> item in Authors)
            //{
            //    Console.WriteLine($"Author Name : {item.Key}   and No. of publications : {item.Value}");
            //}
            //Authors.Remove("Charles Dickens");
            //Console.WriteLine("After Removal");
            //foreach (KeyValuePair<string, Int16> item in Authors)
            //{
            //    Console.WriteLine($"Author Name : {item.Key}   and No. of publications : {item.Value}");
            //}
            //Console.WriteLine(Authors.ContainsKey("Premchand"));
            //Console.WriteLine(Authors.ContainsValue(20));
        }
    }
}
